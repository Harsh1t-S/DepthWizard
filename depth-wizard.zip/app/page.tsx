import DepthWizardWorkspace from '@/components/depthwizard-workspace'

export default function Page() {
  return <DepthWizardWorkspace />
}
