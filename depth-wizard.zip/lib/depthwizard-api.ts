const API_URL = (process.env.NEXT_PUBLIC_API_URL || process.env.VITE_API_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')

export type BackendHealth = { ok: boolean; model?: string; message?: string }
export type AnalysisResult = Record<string, unknown>

export async function checkHealth(): Promise<BackendHealth> {
  try {
    const response = await fetch(`${API_URL}/health`, { cache: 'no-store' })
    if (!response.ok) return { ok: false, message: `Backend returned ${response.status}` }
    const data = await response.json().catch(() => ({}))
    return { ok: true, model: data.model || data.depth_model || data.model_name }
  } catch {
    return { ok: false, message: 'Backend connection unavailable' }
  }
}

export async function analyzeTerrain(input: {
  image: File
  calibration: 'none' | 'dem' | 'gcp'
  dem?: File
  gcp?: File
  groundTruth?: File
}): Promise<AnalysisResult> {
  const form = new FormData()
  form.append('image', input.image)
  form.append('calibration', input.calibration)
  if (input.dem) form.append('dem', input.dem)
  if (input.gcp) form.append('gcp', input.gcp)
  if (input.groundTruth) form.append('ground_truth', input.groundTruth)
  const response = await fetch(`${API_URL}/analyze`, { method: 'POST', body: form })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.detail || data.message || 'Terrain analysis failed')
  return data
}

export function apiUrl(path: string) {
  return path.startsWith('http') ? path : `${API_URL}${path.startsWith('/') ? path : `/${path}`}`
}

export function findArtifact(result: AnalysisResult, keys: string[]) {
  for (const key of keys) {
    const value = result[key]
    if (typeof value === 'string' && value.length > 0) return apiUrl(value)
  }
  return undefined
}

export { API_URL }
